<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=julio_kearsipan',
    'username' => 'julio',
    'password' => 'pico',
    'charset' => 'utf8',
];
